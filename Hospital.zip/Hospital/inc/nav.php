<div class="naviGation">
			<ul><li><a href="">Receptionist</a></li></ul>
			<ul><li><a href="">Doctors Area</a></li></ul>
			<ul><li><a href="contact.php">Patient Area</a></li></ul>
			
			
			</div>