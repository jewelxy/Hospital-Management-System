<div class="socialIcon"> 
					<a href=""> <img src="images/fixedicon/fb.png" alt="facebook" /> </a>
					<a href=""> <img src="images/fixedicon/go.png" alt="googleplus" /> </a>
					<a href=""> <img src="images/fixedicon/tw.png" alt="twitter" /> </a>
					<a href=""> <img src="images/fixedicon/sk.png" alt="skype" /> </a>
			</div>