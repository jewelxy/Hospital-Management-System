<!--bigFooter-->
		<div class="bigFooter"> 
		
			<div class="bigFooter1">
				<img src="images/page3_img3.jpg" alt="" />
			</div>
			<div class="bigFooter2">
			<img src="images/page3_img4.jpg" alt="" />
			</div>
			<div class="bigFooter3">
			<img src="images/support.png" alt="" />
			</div>
		
		</div>
		
		<!--footer--->
		
		<div class="footerWrapper clear"> 
		<p> @copyright || UU CSE (Project-2018) </p>
		</div>
		
	
	</div>
</body>
</html>