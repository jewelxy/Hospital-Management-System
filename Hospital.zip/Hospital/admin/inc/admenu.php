 <div id="cm-menu">
            <nav class="cm-navbar cm-navbar-primary">
                <div class="cm-flex"><a href="dashboard.php">HMS Admin</a></div>
                <div class="btn btn-primary md-menu-white" data-toggle="cm-menu"></div>
            </nav>
            <div id="cm-menu-content">
                <div id="cm-menu-items-wrapper">
                    <div id="cm-menu-scroller">
                        <ul class="cm-menu-items">
                            <li class="active"><a href="index.php" class="sf-house">Home</a></li>
                               <li class="cm-submenu">
                                <a class="sf-window-layout">Pages <span class="caret"></span></a>
                                <ul>
                                    <li><a href="view_patient.php">View Patient</a></li>
                                    
                                </ul>
                            </li>
                           
                            <li><a href="notepad.php" class="sf-notepad">Text Editor</a></li>
                            <li><a href="index.php" class="sf-lock-open">Login page</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>